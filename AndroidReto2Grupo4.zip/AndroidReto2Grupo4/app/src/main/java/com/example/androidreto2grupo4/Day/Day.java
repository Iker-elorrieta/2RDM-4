package com.example.androidreto2grupo4.Day;

public class Day {
    private String letter;
    private String number;

    public Day(String letter, String number) {
        this.letter = letter;
        this.number = number;
    }

    public String getLetter() {
        return letter;
    }

    public String getNumber() {
        return number;
    }
}